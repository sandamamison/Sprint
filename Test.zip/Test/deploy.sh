#!/bin/bash

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$BASE_DIR/src/main/java"
WEB_DIR="$BASE_DIR"
CLASSES_DIR="$WEB_DIR/WEB-INF/classes"

TOMCAT_LIB="/home/andriantsoa/Documents/apache-tomcat-10.0.16/lib/servlet-api.jar"
FRAMEWORK_JAR="$WEB_DIR/WEB-INF/lib/ProcessRequest.jar"

TOMCAT_WEBAPPS="/home/andriantsoa/Documents/apache-tomcat-10.0.16/webapps"
APP_NAME="Sprint(FW)"

echo "=== NETTOYAGE ET PRÉPARATION ==="
rm -rf "$CLASSES_DIR"
mkdir -p "$CLASSES_DIR"

echo "=== COMPILATION DES CONTROLEURS ==="
FILES=$(find "$SRC_DIR" -name "*.java" 2>/dev/null)

if [ -z "$FILES" ]; then
    echo "[Erreur] Aucun fichier .java trouvé dans : $SRC_DIR"
    exit 1
fi

javac -cp "$TOMCAT_LIB:$FRAMEWORK_JAR" -d "$CLASSES_DIR" $FILES

if [ $? -ne 0 ]; then
    echo "[Erreur] La compilation a échoué."
    exit 1
fi

echo "=== DEPLOIEMENT VERS TOMCAT ==="
rm -rf "$TOMCAT_WEBAPPS/$APP_NAME"
mkdir -p "$TOMCAT_WEBAPPS/$APP_NAME"

cp -r "$WEB_DIR/WEB-INF" "$TOMCAT_WEBAPPS/$APP_NAME/"
cp "$WEB_DIR/Test.html" "$TOMCAT_WEBAPPS/$APP_NAME/" 2>/dev/null

echo "=== REDÉMARRAGE DE TOMCAT ==="
/home/andriantsoa/Documents/apache-tomcat-10.0.16/bin/shutdown.sh
sleep 2
/home/andriantsoa/Documents/apache-tomcat-10.0.16/bin/startup.sh

echo ""
echo "=== TOUT EST PRÊT ! ==="
echo "-> http://localhost:8080/$APP_NAME/Test.html"
echo ""
echo "URLs à tester :"
echo "  http://localhost:8080/$APP_NAME/hello"
echo "  http://localhost:8080/$APP_NAME/bonjour"
echo "  http://localhost:8080/$APP_NAME/home"
echo "  http://localhost:8080/$APP_NAME/inexistant  (→ liste les URLs dispo)"
