package main.java.controller;

import annotation.*;

@Controller
public class TestController {
    public TestController () {
    }

    @UrlMapping(url = "/bonjour")
    public void bonjour() {
        System.out.println("helloo");
    }
}
